#distance seltext1 seltext2 N_d f_r_out f_d_out

set seltext1 "segname NM"
set seltext2 "segname PHEN"
set N_d 100
#setting output file
set f_r_out "distance.dat"

#data process
set sel1 [atomselect top "$seltext1"]
set sel2 [atomselect top "$seltext2"]
set nf [molinfo top get numframes]


set outfile [open $f_r_out w]
for {set i 0} {$i < $nf} {incr i} {
    puts "frame $i of $nf"
    $sel1 frame $i
    $sel2 frame $i
    set com1 [measure center $sel1 weight mass]
    set com2 [measure center $sel2 weight mass]
    set dis [veclength [vecsub $com1 $com2]]
    set simdata($i.r) $dis
    puts $outfile "$i   $simdata($i.r)"
}
close $outfile