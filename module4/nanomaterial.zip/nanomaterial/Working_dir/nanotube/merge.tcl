#load nanomaterial
package require topotools 1.7
set midlist {}
set mol [mol new nanotube.psf waitfor all]
mol addfile nanotube.pdb

#load molecule in system
lappend midlist $mol
set mol [mol new phenol.psf waitfor all]
mol addfile phenol.pdb $mol

#moving molecule 
set sel [atomselect top all]
$sel moveby {0.0 20.0 0.0}
    lappend midlist $mol
#do the magic
set mol [::TopoTools::mergemols $midlist]

animate write psf nanotube_sim_temp.psf $mol
animate write pdb nanotube_sim_temp.pdb $mol